from sentence_transformers import SentenceTransformer, util


def gen_prompt(q,a):
    model = SentenceTransformer('all-MiniLM-L6-v2')

    qa_text = f"Q: {q} A: {a}"
    prompt = model.encode(qa_text, convert_to_tensor=True)

    return prompt.numpy()