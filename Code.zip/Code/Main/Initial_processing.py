import numpy as np




def dataa(Pt,Qt,Label):
    qt = process(Qt)
    pt = process(Pt)
    qt = np.resize(qt, np.shape(pt))

    Data = np.column_stack((qt, pt))

    Label=[Label[i][0] for i in range(len(Label))]

    return Data,Label