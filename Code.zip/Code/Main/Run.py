import Read
import Initial_processing
import TQ_RAGNetLLM.PAQ_RAG_Model
import Prompt_generation
import Proposed_CaSOA_RAGNet.PAQ_RAG_Model
import Proposed_CaSOA_RAGNet.GPT_NEOX_LLM_Model


def callmain(dts,kv):
    PRE,REC,F1_S=[],[],[]
    if dts == 'XQUAD':
        Question, Passage, Label = Read.read_dts_XQUAD('Dataset/xquad.en.json')
    else:
        Question, Passage, Label = Read.read_dts_MLQA('Dataset/MLQA_V1/*/*')


    data,Label=Initial_processing.dataa(Passage,Question,Label)
    batch_size=16
    gen_answer=Proposed_CaSOA_RAGNet.PAQ_RAG_Model.gen_answ(Question, Passage, Label, batch_size)
    prompt=Prompt_generation.gen_prompt(Question,gen_answer,kv)

    Proposed_CaSOA_RAGNet.GPT_NEOX_LLM_Model.classify(prompt, PRE, REC, F1_S)
    ################## Comparative Method ###############


    F1_S=[2*PRE[i]*REC[i]/(PRE[i]+REC[i]) for i in range(len(PRE))]
    return PRE,REC,F1_S
