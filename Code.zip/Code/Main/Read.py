import json
import glob

def read_dts_XQUAD(filename):
    with open(filename) as user_file:
        file_contents = user_file.read()
    parsed_json = json.loads(file_contents)
    Question,Passage,Label=[],[],[]
    for i in range(len(parsed_json["data"])):
        for j in range(len(parsed_json["data"][i]['paragraphs'])):

            Passage.append(parsed_json["data"][i]['paragraphs'][j]['context'])
            temp,temp1=[],[]
            for k in range(len(parsed_json["data"][i]['paragraphs'][j]['qas'])):
                temp.append(parsed_json["data"][i]['paragraphs'][j]['qas'][k]['question'])
                temp1.append(parsed_json["data"][i]['paragraphs'][j]['qas'][k]['answers'][0]['answer_start'])
            Question.append(temp)
            Label.append(temp1)

    return Question,Passage,Label


def read_dts_MLQA(path):
    filenames=glob.glob(path)
    Question, Passage, Label = [], [], []
    for i in range(len(filenames)):
        with open(filenames[i]) as user_file:
            file_contents = user_file.read()
        parsed_json = json.loads(file_contents)

        for i in range(len(parsed_json["data"])):
            for j in range(len(parsed_json["data"][i]['paragraphs'])):

                Passage.append(parsed_json["data"][i]['paragraphs'][j]['context'])
                temp,temp1=[],[]
                for k in range(len(parsed_json["data"][i]['paragraphs'][j]['qas'])):
                    temp.append(parsed_json["data"][i]['paragraphs'][j]['qas'][k]['question'])
                    #print(parsed_json["data"][i]['paragraphs'][j]['qas'][k]['answers'])
                    temp1.append(parsed_json["data"][i]['paragraphs'][j]['qas'][k]['answers'][0]['answer_start'])
                Question.append(temp)
                Label.append(temp1)

    return Question,Passage,Label