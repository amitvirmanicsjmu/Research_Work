import numpy as np

# -----------------------------
# Function to optimize
# -----------------------------
def f(x):
    return x**4 - 3*x**3 + 2

# -----------------------------
# Numerical derivative (secant form)
# -----------------------------
def derivative(x, eps=1e-6):
    return (f(x + eps) - f(x)) / eps

# -----------------------------
# Secant optimization method
# -----------------------------
def secant_optimization(x0, x1, tol=1e-6, max_iter=100):
    for i in range(max_iter):

        f_x0 = derivative(x0)
        f_x1 = derivative(x1)

        # avoid division by zero
        if abs(f_x1 - f_x0) < 1e-12:
            print("Division near zero; stopping.")
            break

        # secant update equation
        x2 = x1 - f_x1 * (x1 - x0) / (f_x1 - f_x0)

        # convergence check
        if abs(x2 - x1) < tol:
            return x2

        x0, x1 = x1, x2

    return x1

def Algm():
    x_min = secant_optimization(x0=0.0, x1=2.0)

    return x_min
