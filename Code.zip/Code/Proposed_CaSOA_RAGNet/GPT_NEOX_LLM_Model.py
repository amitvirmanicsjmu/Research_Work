from transformers import GPTNeoForCausalLM, GPT2Tokenizer
from Main import Metrics
import torch



def classify(gen_prompt,PRE,REC,F1_S):
    # Load smaller GPT-Neo model
    model_name = "EleutherAI/gpt-neo-1.3B"
    custom_cache_dir = "Main"

    model = GPTNeoForCausalLM.from_pretrained(model_name, cache_dir=custom_cache_dir, device_map="cpu")

    # Run on CUDA if available
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model.to(device)

    # Test input
    input_text = gen_prompt


    refined_answer=model.predict(input_text)
    gen_prompt=str(gen_prompt)

    pre=Metrics.calculate_precision_set(gen_prompt,refined_answer)

    rec=Metrics.calculate_recall(gen_prompt,refined_answer)

    fm = Metrics.calculate_f1(gen_prompt,refined_answer)

    PRE.append(pre)
    REC.append(rec)
    F1_S.append(fm)
