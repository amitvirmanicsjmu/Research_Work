import tensorflow as tf

def neighbour_mse_loss():
    def loss(y_true, y_pred):
        # MSE
        mse = tf.reduce_mean(tf.square(y_true - y_pred))
        # Cosine similarity as neighbour loss
        y_pred_norm = tf.nn.l2_normalize(y_pred, axis=1)
        y_true_norm = tf.nn.l2_normalize(y_true, axis=1)
        neighbour_loss = tf.reduce_mean(1 - tf.reduce_sum(y_pred_norm * y_true_norm, axis=1))
        return mse + neighbour_loss
    return loss