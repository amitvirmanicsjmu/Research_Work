import tensorflow as tf
from tensorflow.keras.layers import Input, Dense, Concatenate
from tensorflow.keras.models import Model
from TQ_RAGNetLLM.Loss_fn import *
from sentence_transformers import SentenceTransformer
import Proposed_CaSOA_RAGNet.AuSOA
import numpy as np

def gen_answ(Q, P, Y,batch_size):
    EMB_DIM = 384
    HIDDEN = 512

    embedder = SentenceTransformer('all-MiniLM-L6-v2')

    # Inputs
    question_input = Input(shape=(EMB_DIM,), name="question_embedding")
    passage_input  = Input(shape=(EMB_DIM,), name="passage_embedding")

    # Fusion (RAG-style)
    x = Concatenate()([question_input, passage_input])
    x = Dense(HIDDEN, activation="relu")(x)
    x = Dense(HIDDEN, activation="relu")(x)

    answer_output = Dense(EMB_DIM, activation="linear", name="answer_embedding")(x)

    model = Model(inputs=[question_input, passage_input], outputs=answer_output)

    # Embed Q, P, Y
    Q_emb = np.array(embedder.encode(Q), dtype=np.float32)
    P_emb = np.array(embedder.encode(P), dtype=np.float32)
    Y_emb = np.array(Y, dtype=np.float32)

    # Compile with batch-agnostic neighbour+MSE loss
    model.compile(
        optimizer=tf.keras.optimizers.Adam(Proposed_CaSOA_RAGNet.AuSOA.Algm()),
        loss=neighbour_mse_loss()
    )

    # Train
    model.fit([Q_emb, P_emb], Y_emb, epochs=10, batch_size=batch_size)

    # Predict
    predicted_answer = model.predict([Q_emb, P_emb])
    return predicted_answer
